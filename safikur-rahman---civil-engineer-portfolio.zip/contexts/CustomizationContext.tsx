import React, { createContext, useState, useEffect, useContext, ReactNode, useCallback } from 'react';
import { initialData } from '../data';

// Helper to deeply set a value in a nested object
const set = (obj: any, path: string, value: any) => {
  const keys = path.split('.');
  let current = obj;
  for (let i = 0; i < keys.length - 1; i++) {
    if (current[keys[i]] === undefined) {
      current[keys[i]] = {};
    }
    current = current[keys[i]];
  }
  current[keys[keys.length - 1]] = value;
  return obj;
};

type Theme = 'light' | 'dark';

interface CustomizationContextType {
  isEditMode: boolean;
  toggleEditMode: () => void;
  accentColor: string;
  setAccentColor: (color: string) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  data: typeof initialData;
  updateData: (path: string, value: any) => void;
  resetData: () => void;
}

const CustomizationContext = createContext<CustomizationContextType | undefined>(undefined);

export const CustomizationProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [isEditMode, setIsEditMode] = useState(false);
  const [accentColor, setAccentColorState] = useState('#38bdf8');
  const [theme, setThemeState] = useState<Theme>('light');
  const [data, setData] = useState(() => {
    try {
      const storedData = localStorage.getItem('portfolioData');
      return storedData ? JSON.parse(storedData) : initialData;
    } catch (error) {
      console.error("Failed to parse portfolio data from localStorage", error);
      return initialData;
    }
  });

  useEffect(() => {
    try {
      const storedColor = localStorage.getItem('portfolioAccentColor');
      if (storedColor) {
        setAccentColorState(storedColor);
        document.documentElement.style.setProperty('--accent-color', storedColor);
      }
      
      const storedTheme = localStorage.getItem('portfolioTheme');
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      const initialTheme = storedTheme ? (storedTheme as Theme) : (prefersDark ? 'dark' : 'light');
      setThemeState(initialTheme);
      document.documentElement.classList.toggle('dark', initialTheme === 'dark');

    } catch (error) {
      console.error("Failed to load settings from localStorage", error);
    }
  }, []);

  const setAccentColor = (color: string) => {
    setAccentColorState(color);
    document.documentElement.style.setProperty('--accent-color', color);
    try {
      localStorage.setItem('portfolioAccentColor', color);
    } catch (error) {
       console.error("Failed to save accent color to localStorage", error);
    }
  };
  
  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
    try {
        localStorage.setItem('portfolioTheme', newTheme);
    } catch (error) {
        console.error("Failed to save theme to localStorage", error);
    }
  };

  const updateData = useCallback((path: string, value: any) => {
    setData(currentData => {
      const newData = JSON.parse(JSON.stringify(currentData)); // Deep copy
      set(newData, path, value);
      try {
        localStorage.setItem('portfolioData', JSON.stringify(newData));
      } catch (error) {
        console.error("Failed to save portfolio data to localStorage", error);
      }
      return newData;
    });
  }, []);

  const resetData = () => {
    if (window.confirm('Are you sure you want to reset all content and customizations to the default?')) {
        setData(initialData);
        setAccentColor('#38bdf8'); // Reset to default sky blue
        setTheme(window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
        try {
            localStorage.removeItem('portfolioData');
            localStorage.removeItem('portfolioAccentColor');
            localStorage.removeItem('portfolioTheme');
        } catch (error) {
             console.error("Failed to clear localStorage", error);
        }
    }
  };

  const toggleEditMode = () => setIsEditMode(prev => !prev);

  const value = {
    isEditMode,
    toggleEditMode,
    accentColor,
    setAccentColor,
    theme,
    setTheme,
    data,
    updateData,
    resetData,
  };

  return (
    <CustomizationContext.Provider value={value}>
      {children}
    </CustomizationContext.Provider>
  );
};

export const useCustomization = (): CustomizationContextType => {
  const context = useContext(CustomizationContext);
  if (context === undefined) {
    throw new Error('useCustomization must be used within a CustomizationProvider');
  }
  return context;
};