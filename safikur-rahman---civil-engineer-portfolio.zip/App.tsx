import React from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Summary from './components/Summary';
import Experience from './components/Experience';
import Education from './components/Education';
import Skills from './components/Skills';
import Projects from './components/Projects';
import CertificationsAwards from './components/CertificationsAwards';
import Testimonials from './components/Testimonials';
import Contact from './components/Contact';
import Footer from './components/Footer';
import { useCustomization } from './contexts/CustomizationContext';
import CustomizationPanel from './components/CustomizationPanel';

const App: React.FC = () => {
  const { data, theme } = useCustomization();
  
  React.useEffect(() => {
    document.title = `${data.personalInfo.name} | ${data.personalInfo.title}`;
  }, [data.personalInfo.name, data.personalInfo.title]);

  return (
    <div className={`${theme} bg-gray-50 dark:bg-gray-900 text-gray-700 dark:text-gray-300 font-sans leading-relaxed transition-colors duration-300`}>
      <CustomizationPanel />
      <div className="lg:flex">
        <Header />
        <main className="lg:w-2/3 lg:ml-auto p-6 sm:p-8 md:p-12">
            <Hero data={data.personalInfo} />
            <div id="content" className="space-y-16 md:space-y-24">
              <Summary content={data.summary} />
              <Experience data={data.experience} />
              <Education data={data.education} />
              <Projects data={data.projects} />
              <Skills data={data.skills} />
              <CertificationsAwards data={data.accomplishments} />
              <Testimonials data={data.testimonials} />
              <Contact data={data.contact} />
            </div>
            <Footer />
        </main>
      </div>
    </div>
  );
};

export default App;