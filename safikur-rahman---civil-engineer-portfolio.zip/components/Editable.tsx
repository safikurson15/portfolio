
import React, { useRef } from 'react';
import { useCustomization } from '../contexts/CustomizationContext';

interface EditableProps {
  path: string;
  children: React.ReactNode;
  as?: React.ElementType;
  className?: string;
  [x: string]: any; // for other props like href
}

export const Editable: React.FC<EditableProps> = ({ path, children, as = 'div', className, ...props }) => {
  const { isEditMode, updateData } = useCustomization();
  const elementRef = useRef<HTMLElement>(null);

  const handleBlur = () => {
    if (elementRef.current) {
      const newValue = elementRef.current.innerText;
      // Only update if the value has actually changed to avoid unnecessary re-renders
      if (newValue !== children) {
          updateData(path, newValue);
      }
    }
  };

  const dynamicClassName = `${className || ''} ${isEditMode ? 'editable-outline' : ''}`;

  return React.createElement(
    as,
    {
      ...props,
      ref: elementRef,
      contentEditable: isEditMode,
      suppressContentEditableWarning: true,
      onBlur: handleBlur,
      className: dynamicClassName,
      style: isEditMode ? { cursor: 'text' } : {},
    },
    children
  );
};
