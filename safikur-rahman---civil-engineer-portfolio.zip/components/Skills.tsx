import React from 'react';
import Section from './Section';
import { useCustomization } from '../contexts/CustomizationContext';
import { Editable } from './Editable';


const SkillCategory: React.FC<{ title: string; items: string[]; categoryKey: string }> = ({ title, items, categoryKey }) => {
    const { isEditMode, updateData } = useCustomization();

    const addSkill = () => {
        const newSkill = 'New Skill';
        updateData(`skills.${categoryKey}`, [...items, newSkill]);
    };

    const removeSkill = (index: number) => {
        updateData(`skills.${categoryKey}`, items.filter((_, i) => i !== index));
    };

    return (
        <div>
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">{title}</h3>
            <div className="flex flex-wrap gap-2">
                {items.map((item, index) => (
                    <div key={index} className="relative group">
                        <Editable
                            as="span"
                            path={`skills.${categoryKey}.${index}`}
                            className="bg-[var(--accent-color)]/10 text-[var(--accent-color)] px-4 py-2 rounded-full text-sm font-semibold block"
                        >
                            {item}
                        </Editable>
                        {isEditMode && (
                             <button
                                onClick={() => removeSkill(index)}
                                className="absolute -top-1 -right-1 bg-red-500 w-4 h-4 text-white text-xs rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                                &times;
                            </button>
                        )}
                    </div>
                ))}
                 {isEditMode && (
                    <button onClick={addSkill} className="bg-gray-200/50 dark:bg-gray-700/50 text-gray-600 dark:text-gray-300 px-4 py-2 rounded-full text-sm font-medium hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
                        + Add
                    </button>
                 )}
            </div>
        </div>
    );
};


const Skills: React.FC<{ data: any }> = ({ data }) => {
  return (
    <Section id="skills" title="Skills & Expertise">
      <div className="space-y-8">
        <SkillCategory title="Technical Software & Tools" items={data.softwareAndTools} categoryKey="softwareAndTools" />
        <SkillCategory title="Professional Skills" items={data.professionalSkills} categoryKey="professionalSkills" />
        <SkillCategory title="Languages" items={data.languages} categoryKey="languages" />
      </div>
    </Section>
  );
};

export default Skills;