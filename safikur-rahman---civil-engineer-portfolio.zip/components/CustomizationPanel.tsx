import React from 'react';
import { useCustomization } from '../contexts/CustomizationContext';
import { CogIcon, EyeIcon, MoonIcon, SunIcon } from './Icons';

const CustomizationPanel: React.FC = () => {
    const { 
        isEditMode, 
        toggleEditMode, 
        accentColor, 
        setAccentColor,
        theme,
        setTheme,
        resetData
    } = useCustomization();

    return (
        <div className="fixed bottom-4 right-4 bg-white/80 dark:bg-gray-800/80 backdrop-blur-md text-gray-800 dark:text-white p-3 rounded-lg shadow-2xl z-50 border border-gray-200 dark:border-gray-700 transition-colors duration-300">
            <div className="flex items-center space-x-3">
                <button title="Toggle Theme" onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')} className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 transition-colors">
                    {theme === 'light' ? <MoonIcon className="text-gray-700" /> : <SunIcon className="text-yellow-400" />}
                </button>
                 <div className="h-6 w-px bg-gray-300 dark:bg-gray-600"></div>

                <label htmlFor="editModeToggle" title="Toggle Edit Mode" className="flex items-center cursor-pointer group">
                    <div className="relative">
                        <input id="editModeToggle" type="checkbox" className="sr-only" checked={isEditMode} onChange={toggleEditMode} />
                        <div className="block bg-gray-300 dark:bg-gray-600 w-12 h-6 rounded-full"></div>
                        <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${isEditMode ? 'transform translate-x-6 bg-[var(--accent-color)]' : 'dark:bg-gray-400'}`}></div>
                    </div>
                </label>
                
                {isEditMode && (
                  <>
                    <div className="h-6 w-px bg-gray-300 dark:bg-gray-600"></div>
                    <div className="relative">
                        <label htmlFor="accentColorPicker" title="Change Accent Color" className="flex items-center cursor-pointer">
                             <div className="w-6 h-6 rounded-full border-2 dark:border-gray-500" style={{ backgroundColor: accentColor }}></div>
                             <input
                                id="accentColorPicker"
                                type="color"
                                value={accentColor}
                                onChange={(e) => setAccentColor(e.target.value)}
                                className="absolute w-6 h-6 opacity-0 cursor-pointer"
                            />
                        </label>
                    </div>
                     <div className="h-6 w-px bg-gray-300 dark:bg-gray-600"></div>
                    <button onClick={resetData} className="text-sm font-medium text-red-500 hover:text-red-600 dark:text-red-400 dark:hover:text-red-300 transition-colors">
                        Reset
                    </button>
                  </>
                )}
            </div>
        </div>
    );
};

export default CustomizationPanel;