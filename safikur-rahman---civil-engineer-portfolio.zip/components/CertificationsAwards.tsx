import React from 'react';
import Section from './Section';
import { useCustomization } from '../contexts/CustomizationContext';
import { TrashIcon } from './Icons';

const ListCard: React.FC<{ title: string, items: string[], categoryKey: string }> = ({ title, items, categoryKey }) => {
    const { isEditMode, updateData } = useCustomization();
    
    const addItem = () => {
        const newItem = prompt(`Enter new item for ${title}:`);
        if (newItem) {
            updateData(`accomplishments.${categoryKey}`, [...items, newItem]);
        }
    };

    const removeItem = (index: number) => {
        updateData(`accomplishments.${categoryKey}`, items.filter((_, i) => i !== index));
    };

    return (
        <div>
            <h3 className="text-lg font-bold text-gray-800 dark:text-white mb-4">{title}</h3>
            <ul className="space-y-2">
                {items.map((item, index) => (
                    <li key={index} className="flex items-center group text-gray-600 dark:text-gray-400">
                       <span className="mr-2 text-[var(--accent-color)]">▸</span>
                       <span>{item}</span>
                       {isEditMode && (
                         <button onClick={() => removeItem(index)} className="ml-auto text-red-500 opacity-0 group-hover:opacity-100">
                           <TrashIcon className="w-4 h-4" />
                         </button>
                       )}
                    </li>
                ))}
            </ul>
            {isEditMode && (
                <button onClick={addItem} className="text-sm text-[var(--accent-color)] mt-4 hover:underline">
                    + Add Item
                </button>
            )}
        </div>
    );
};

const CertificationsAwards: React.FC<{ data: any }> = ({ data }) => {
  return (
    <Section id="accomplishments" title="Accomplishments">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-12">
        <ListCard title="Certifications" items={data.certifications} categoryKey="certifications" />
        <ListCard title="Awards & Honors" items={data.awards} categoryKey="awards" />
        <ListCard title="Workshops" items={data.workshops} categoryKey="workshops" />
        <ListCard title="Webinars" items={data.webinars} categoryKey="webinars" />
        <ListCard title="Interests & Activities" items={data.interests} categoryKey="interests" />
      </div>
    </section>
  );
};

export default CertificationsAwards;