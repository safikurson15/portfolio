import React from 'react';
import Section from './Section';
import { Editable } from './Editable';

interface SummaryProps {
    content: string;
}

const Summary: React.FC<SummaryProps> = ({ content }) => {
    return (
        <Section id="summary" title="Summary">
            <Editable as="p" path="summary" className="text-lg text-gray-600 dark:text-gray-400 leading-relaxed">
                {content}
            </Editable>
        </Section>
    )
}

export default Summary;