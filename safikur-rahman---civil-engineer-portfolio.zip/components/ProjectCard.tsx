import React, { useState } from 'react';
import { TrashIcon, ChevronLeftIcon, ChevronRightIcon } from './Icons';
import { useCustomization } from '../contexts/CustomizationContext';
import { Editable } from './Editable';

interface Project {
  title: string;
  level: string;
  date: string;
  description: string;
  images: string[];
}

interface ProjectCardProps {
  project: Project;
  index: number;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project, index }) => {
  const { isEditMode, updateData, data } = useCustomization();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const removeProject = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const newProjects = data.projects.filter((_, i) => i !== index);
    updateData('projects', newProjects);
  };

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % project.images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + project.images.length) % project.images.length);
  };

  return (
    <a 
        href="#"
        onClick={(e) => isEditMode && e.preventDefault()}
        className="group relative block p-6 bg-white dark:bg-gray-800/50 rounded-lg shadow-md hover:bg-gray-100/50 dark:hover:bg-gray-800 hover:shadow-lg hover:shadow-[var(--accent-color)]/10 transition-all duration-300"
    >
      <div className="flex flex-col sm:flex-row gap-6">
          <div className="w-full sm:w-48 h-32 sm:h-auto flex-shrink-0 relative overflow-hidden rounded-md group/image">
            <img src={project.images[currentImageIndex]} alt={`${project.title} screenshot ${currentImageIndex + 1}`} className="w-full h-full object-cover rounded-md transition-opacity duration-300" />
            
            {project.images.length > 1 && (
              <>
                <button
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); prevImage(); }}
                  className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/40 p-1 rounded-full text-white opacity-0 group-hover/image:opacity-100 focus:opacity-100 transition-opacity z-10"
                  aria-label="Previous image"
                >
                  <ChevronLeftIcon />
                </button>
                 <button
                  onClick={(e) => { e.preventDefault(); e.stopPropagation(); nextImage(); }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/40 p-1 rounded-full text-white opacity-0 group-hover/image:opacity-100 focus:opacity-100 transition-opacity z-10"
                  aria-label="Next image"
                >
                  <ChevronRightIcon />
                </button>

                <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1.5 z-10">
                  {project.images.map((_, dotIndex) => (
                    <button
                      key={dotIndex}
                      onClick={(e) => { e.preventDefault(); e.stopPropagation(); setCurrentImageIndex(dotIndex); }}
                      className={`w-2 h-2 rounded-full transition-colors ${currentImageIndex === dotIndex ? 'bg-white' : 'bg-white/50 hover:bg-white/75'}`}
                      aria-label={`Go to image ${dotIndex + 1}`}
                    />
                  ))}
                </div>
              </>
            )}
          </div>
          <div>
            <Editable as="h3" path={`projects.${index}.title`} className="text-xl font-bold text-gray-800 dark:text-white mb-1 group-hover:text-[var(--accent-color)] transition-colors">{project.title}</Editable>
            <Editable as="p" path={`projects.${index}.level`} className="text-sm font-semibold text-gray-500 dark:text-gray-400 mb-2">{project.level}</Editable>
            <Editable as="p" path={`projects.${index}.description`} className="text-gray-600 dark:text-gray-300 text-sm leading-relaxed">{project.description}</Editable>
          </div>
      </div>
       {isEditMode && (
          <button
              onClick={removeProject}
              className="absolute top-3 right-3 bg-red-600 text-white p-1.5 rounded-full hover:bg-red-700 transition-colors opacity-0 group-hover:opacity-100"
              aria-label="Remove project"
          >
              <TrashIcon />
          </button>
      )}
    </a>
  );
};

export default ProjectCard;