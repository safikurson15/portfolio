import React from 'react';
import { Editable } from './Editable';
import { DownloadIcon, CameraIcon, UploadIcon } from './Icons';
import { useCustomization } from '../contexts/CustomizationContext';

interface HeroProps {
    data: {
        name: string;
        title: string;
        overview: string;
        imageUrl: string;
        resumeUrl: string;
    }
}

const Hero: React.FC<HeroProps> = ({ data }) => {
  const { isEditMode, updateData } = useCustomization();

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateData('personalInfo.imageUrl', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };
  
  const handleCvUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.type !== 'application/pdf') {
        alert('Please upload a PDF file for the CV.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        updateData('personalInfo.resumeUrl', reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <section id="about" className="lg:hidden min-h-[60vh] flex flex-col justify-center py-20">
       <div className="flex flex-col items-center text-center gap-8">
        <div className="relative group w-40 h-40">
            <div className="w-full h-full rounded-full overflow-hidden border-4 border-[var(--accent-color)] shadow-lg">
              <img 
                src={data.imageUrl}
                alt={data.name} 
                className="w-full h-full object-cover" 
              />
            </div>
             {isEditMode && (
              <label className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-full cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity">
                <input type="file" className="sr-only" accept="image/*" onChange={handleImageUpload} />
                <div className="text-center text-white">
                    <CameraIcon />
                    <span className="text-xs font-bold">Upload</span>
                </div>
              </label>
            )}
        </div>
        <div>
            <Editable as="h1" path="personalInfo.name" className="text-4xl md:text-5xl font-bold text-gray-900 dark:text-white mb-2">
              {data.name}
            </Editable>
            <Editable as="p" path="personalInfo.title" className="text-xl md:text-2xl text-[var(--accent-color)] font-semibold">
              {data.title}
            </Editable>
        </div>
        <div className="relative group">
            <a href={data.resumeUrl} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 bg-[var(--accent-color)] text-white font-bold py-3 px-6 rounded-lg hover:brightness-110 transition-all transform hover:scale-105 shadow-lg">
                <DownloadIcon />
                Download CV
            </a>
            {isEditMode && (
              <label className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-lg cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity">
                <input type="file" className="sr-only" accept=".pdf" onChange={handleCvUpload} />
                <div className="text-center text-white">
                    <UploadIcon />
                    <span className="text-xs font-bold">Change CV</span>
                </div>
              </label>
            )}
        </div>
       </div>
    </section>
  );
};

export default Hero;