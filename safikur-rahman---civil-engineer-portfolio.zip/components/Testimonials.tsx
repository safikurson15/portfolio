import React from 'react';
import Section from './Section';
import { useCustomization } from '../contexts/CustomizationContext';
import { Editable } from './Editable';
import { PlusIcon, TrashIcon } from './Icons';

interface Testimonial {
    quote: string;
    name: string;
    title: string;
}

const Testimonials: React.FC<{ data: Testimonial[] }> = ({ data }) => {
    const { isEditMode, updateData } = useCustomization();

    const addTestimonial = () => {
        const newTestimonial = {
            quote: "Enter a compelling quote here.",
            name: "Full Name",
            title: "Title, Company"
        };
        updateData('testimonials', [...data, newTestimonial]);
    };

    const removeTestimonial = (index: number) => {
        updateData('testimonials', data.filter((_, i) => i !== index));
    };

    return (
        <Section id="testimonials" title="Testimonials">
            <div className="space-y-8">
                {data.map((testimonial, index) => (
                    <div key={index} className="group relative p-6 bg-white dark:bg-gray-800/50 rounded-lg shadow-md">
                         <div className="absolute top-4 left-4 text-6xl text-[var(--accent-color)]/20 font-serif">“</div>
                        <Editable as="blockquote" path={`testimonials.${index}.quote`} className="text-lg italic text-gray-700 dark:text-gray-300 relative z-10">
                            {testimonial.quote}
                        </Editable>
                        <div className="mt-4 text-right">
                            <Editable as="p" path={`testimonials.${index}.name`} className="font-bold text-gray-800 dark:text-white">{testimonial.name}</Editable>
                            <Editable as="p" path={`testimonials.${index}.title`} className="text-sm text-gray-500 dark:text-gray-400">{testimonial.title}</Editable>
                        </div>
                        {isEditMode && (
                            <button
                                onClick={() => removeTestimonial(index)}
                                className="absolute top-3 right-3 bg-red-600 text-white p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                                aria-label="Remove testimonial"
                            >
                                <TrashIcon />
                            </button>
                        )}
                    </div>
                ))}
                {isEditMode && (
                    <div className="text-center pt-4">
                        <button onClick={addTestimonial} className="bg-gray-700 hover:bg-[var(--accent-color)] text-white font-bold py-2 px-4 rounded-full inline-flex items-center transition-colors">
                            <PlusIcon />
                            <span className="ml-2">Add Testimonial</span>
                        </button>
                    </div>
                )}
            </div>
        </Section>
    );
};

export default Testimonials;