import React from 'react';
import Section from './Section';
import ProjectCard from './ProjectCard';
import { useCustomization } from '../contexts/CustomizationContext';
import { PlusIcon } from './Icons';

const Projects: React.FC<{ data: any[] }> = ({ data }) => {
  const { isEditMode, updateData } = useCustomization();
  
  const addProject = () => {
    const newProject = {
      title: 'New Project Title',
      level: 'Project Level',
      date: 'Date Range',
      description: 'A brief description of the new project.',
      images: ['https://picsum.photos/seed/new-project/400/300'],
    };
    updateData('projects', [...data, newProject]);
  };

  return (
    <Section id="projects" title="Academic Projects">
      <div className="space-y-8">
        {data.map((project, index) => (
          <ProjectCard key={index} project={project} index={index} />
        ))}
         {isEditMode && (
            <div className="text-center pt-4">
               <button onClick={addProject} className="bg-gray-700 hover:bg-[var(--accent-color)] text-white font-bold py-2 px-4 rounded-full inline-flex items-center transition-colors">
                  <PlusIcon />
                  <span className="ml-2">Add Project</span>
              </button>
            </div>
        )}
      </div>
    </Section>
  );
};

export default Projects;