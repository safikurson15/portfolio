import React, { useState } from 'react';
import Section from './Section';
import { useCustomization } from '../contexts/CustomizationContext';

const Contact: React.FC<{ data: any[] }> = ({ data }) => {
  const { isEditMode } = useCustomization();
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [status, setStatus] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isEditMode) {
        setStatus("Form submission is disabled in edit mode.");
        return;
    }
    // Basic validation
    if (!formData.name || !formData.email || !formData.message) {
      setStatus('Please fill out all fields.');
      return;
    }
    // Simulate form submission
    setStatus('Thank you for your message! (This is a demo)');
    setFormData({ name: '', email: '', message: '' });
    setTimeout(() => setStatus(''), 3000);
  };


  return (
    <Section id="contact" title="Contact">
        <p className="text-lg text-gray-600 dark:text-gray-400 mb-8 max-w-2xl">
            I'm currently seeking new opportunities and would love to hear from you. Whether you have a question or just want to connect, feel free to reach out.
        </p>

      <div className="max-w-2xl">
          <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                  <label htmlFor="name" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Name</label>
                  <input
                    type="text"
                    name="name"
                    id="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="block w-full px-4 py-3 rounded-md bg-gray-100 dark:bg-gray-800 border-2 border-transparent focus:border-[var(--accent-color)] focus:ring-0 transition"
                    placeholder="Your Name"
                    />
              </div>
              <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Email</label>
                  <input
                    type="email"
                    name="email"
                    id="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="block w-full px-4 py-3 rounded-md bg-gray-100 dark:bg-gray-800 border-2 border-transparent focus:border-[var(--accent-color)] focus:ring-0 transition"
                    placeholder="you@example.com"
                    />
              </div>
              <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Message</label>
                  <textarea
                    name="message"
                    id="message"
                    rows={4}
                    value={formData.message}
                    onChange={handleChange}
                    className="block w-full px-4 py-3 rounded-md bg-gray-100 dark:bg-gray-800 border-2 border-transparent focus:border-[var(--accent-color)] focus:ring-0 transition"
                    placeholder="Your message..."
                    ></textarea>
              </div>
              <div>
                  <button type="submit" className="px-8 py-3 bg-[var(--accent-color)] text-white font-bold rounded-md hover:brightness-110 transition-transform transform hover:scale-105 shadow-lg">
                      Send Message
                  </button>
              </div>
              {status && <p className="mt-4 text-sm">{status}</p>}
          </form>
      </div>
    </Section>
  );
};

export default Contact;