import React from 'react';
import Section from './Section';
import { useCustomization } from '../contexts/CustomizationContext';
import { Editable } from './Editable';
import { PlusIcon, TrashIcon } from './Icons';


const Education: React.FC<{ data: any[] }> = ({ data }) => {
  const { isEditMode, updateData } = useCustomization();
  
  const addEducation = () => {
    const newEdu = {
      date: '202X - 202Y',
      degree: 'New Degree',
      institution: 'University Name',
    };
    updateData('education', [...data, newEdu]);
  };
  
  const removeEducation = (index: number) => {
    updateData('education', data.filter((_, i) => i !== index));
  };
  
  return (
    <Section id="education" title="Education">
      <div className="space-y-8">
        {data.map((edu, index) => (
           <div key={index} className="group relative p-6 bg-white dark:bg-gray-800/50 rounded-lg shadow-md hover:shadow-lg hover:shadow-[var(--accent-color)]/10 transition-all duration-300">
            <div className="flex flex-col md:flex-row gap-4">
              <Editable as="p" path={`education.${index}.date`} className="md:w-1/4 text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">{edu.date}</Editable>
              <div className="md:w-3/4">
                <Editable as="h3" path={`education.${index}.degree`} className="text-xl font-bold text-gray-800 dark:text-white">{edu.degree}</Editable>
                <Editable as="p" path={`education.${index}.institution`} className="text-md text-[var(--accent-color)] font-semibold">{edu.institution}</Editable>
              </div>
            </div>
             {isEditMode && (
                <button 
                  onClick={() => removeEducation(index)}
                  className="absolute top-3 right-3 bg-red-600 text-white p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                  aria-label="Remove education"
                >
                  <TrashIcon />
                </button>
             )}
          </div>
        ))}
         {isEditMode && (
          <div className="text-center pt-4">
             <button onClick={addEducation} className="bg-gray-700 hover:bg-[var(--accent-color)] text-white font-bold py-2 px-4 rounded-full inline-flex items-center transition-colors">
                <PlusIcon />
                <span className="ml-2">Add Education</span>
            </button>
          </div>
        )}
      </div>
    </Section>
  );
};

export default Education;