import React, { useState, useEffect } from 'react';
import { useCustomization } from '../contexts/CustomizationContext';
import { Editable } from './Editable';
import { GitHubIcon, LinkedInIcon } from './Icons';

const socialIcons: { [key: string]: React.ReactNode } = {
    linkedin: <LinkedInIcon />,
    github: <GitHubIcon />,
};

const Header: React.FC = () => {
  const [activeLink, setActiveLink] = useState('about');
  const { data } = useCustomization();
  
  const navLinks = [
    { name: 'About', href: '#about' },
    { name: 'Summary', href: '#summary' },
    { name: 'Experience', href: '#experience' },
    { name: 'Education', href: '#education' },
    { name: 'Projects', href: '#projects' },
    { name: 'Skills', href: '#skills' },
    { name: 'Testimonials', href: '#testimonials'},
    { name: 'Contact', href: '#contact' },
  ];

  useEffect(() => {
    const handleScroll = () => {
      const sections = navLinks.map(link => document.querySelector(link.href));
      const scrollPosition = window.scrollY + window.innerHeight / 2;
      
      let currentSection = 'about';
      for (const section of sections) {
        if (section instanceof HTMLElement) {
          if (section.offsetTop <= scrollPosition) {
            currentSection = section.id;
          } else {
            break;
          }
        }
      }
      setActiveLink(currentSection);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [navLinks]);

  return (
    <header className="hidden lg:flex lg:flex-col lg:justify-between lg:w-1/3 lg:h-screen lg:fixed lg:top-0 lg:left-0 lg:p-12 xl:p-16">
      <div className="flex flex-col gap-8">
        <div>
            <Editable as="h1" path="personalInfo.name" className="text-4xl xl:text-5xl font-bold text-gray-800 dark:text-white">
                {data.personalInfo.name}
            </Editable>
            <Editable as="h2" path="personalInfo.title" className="text-lg xl:text-xl font-medium text-gray-600 dark:text-gray-300 mt-2">
                {data.personalInfo.title}
            </Editable>
        </div>
        
        <nav>
          <ul className="space-y-4">
            {navLinks.map(link => (
              <li key={link.name}>
                <a 
                  href={link.href}
                  className="group flex items-center gap-4 transition-all"
                >
                  <span className={`w-10 h-0.5 transition-all duration-300 ${activeLink === link.href.substring(1) ? 'w-16 bg-[var(--accent-color)]' : 'bg-gray-400 dark:bg-gray-600 group-hover:w-16 group-hover:bg-[var(--accent-color)]'}`}></span>
                  <span className={`text-xs font-bold uppercase tracking-widest transition-colors duration-300 ${activeLink === link.href.substring(1) ? 'text-[var(--accent-color)]' : 'text-gray-500 dark:text-gray-400 group-hover:text-[var(--accent-color)]'}`}>{link.name}</span>
                </a>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      <div className="flex items-center gap-6">
        {data.personalInfo.socialLinks.map(link => (
            <a key={link.platform} href={link.url} target="_blank" rel="noopener noreferrer" className="text-gray-500 dark:text-gray-400 hover:text-[var(--accent-color)] transition-colors">
                {socialIcons[link.platform]}
            </a>
        ))}
      </div>
    </header>
  );
};

export default Header;