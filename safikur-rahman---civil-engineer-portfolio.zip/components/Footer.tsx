import React from 'react';
import { useCustomization } from '../contexts/CustomizationContext';

const Footer: React.FC = () => {
  const { data } = useCustomization();
  
  return (
    <footer className="pt-16 pb-8 text-center text-gray-500 dark:text-gray-500 text-sm">
      <p>
        &copy; {new Date().getFullYear()} {data.personalInfo.name}. All Rights Reserved. <br/>
        Design inspired by professional modern portfolios and built with React & Tailwind CSS.
      </p>
    </footer>
  );
};

export default Footer;