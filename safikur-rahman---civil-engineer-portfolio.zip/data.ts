export const initialData = {
  personalInfo: {
    name: "Safikur Rahman",
    title: "Civil Engineer",
    imageUrl: "https://storage.googleapis.com/aai-web-samples/safikur-rahman-profile-new.jpeg",
    overview: "Dedicated and detail-oriented Civil Engineer with a strong foundation in design, construction, and maintenance of infrastructure projects. Proven ability to manage projects from conception to completion while ensuring compliance with industry standards and regulations. Expertise in structural analysis, site investigation, and construction management. Committed to delivering innovative and sustainable engineering solutions.",
    resumeUrl: "https://storage.googleapis.com/aai-web-samples/safikur-resume.pdf",
    socialLinks: [
        { platform: 'linkedin', url: 'https://www.linkedin.com/' },
        { platform: 'github', url: 'https://github.com/' },
    ]
  },
  summary: "A recent graduate with an M.Tech in Water Resources and Hydraulic Engineering, I bring a solid academic foundation and practical experience from internships and part-time roles. My expertise lies in structural analysis, project management, and utilizing key industry software like AutoCAD and STAAD-PRO. I am passionate about developing sustainable infrastructure and am eager to contribute my skills to a challenging and innovative engineering environment.",
  contact: [
    { icon: 'phone', text: '+91-60017-91390', href: 'tel:+916001791390' },
    { icon: 'mail', text: 'safikurson15@gmail.com', href: 'mailto:safikurson15@gmail.com' },
    { icon: 'location', text: 'Ghograpar, Assam, India', href: '#' },
  ],
  experience: [
    { date: 'Aug 2023 - Present', title: 'Assistant Engineer (Civil)', company: 'M/s Utopian Consultancy and Construction, Nalbari', type: 'Part-Time role focusing on project design, site investigation, and ensuring compliance with industry standards.' },
    { date: 'Internship Period', title: 'Intern', company: 'P.W. (BLDG. & NH) Deptt. Guwahati', type: 'Gained hands-on experience in building and national highway projects, assisting with structural analysis and construction management tasks.' },
    { date: 'Internship Period', title: 'Intern', company: 'P.WD. Mushalpur (R&B) Division', type: 'Contributed to road and bridge projects, focusing on site supervision and quality control processes.' },
  ],
  education: [
    { date: '2023 - 2025', degree: 'M.Tech, Water Resources and Hydraulic Engineering', institution: 'Central Institute of Technology, Kokrajhar' },
    { date: '2020 - 2023', degree: 'B.Tech in Civil Engineering', institution: 'The Assam Kaziranga University, Jorhat' },
    { date: '2017 - 2020', degree: 'Diploma in Civil Engineering', institution: 'Baksa Polytechnic, Baksa' },
  ],
  skills: {
    softwareAndTools: ['AutoCAD', 'STAAD-PRO', 'Microsoft Office', 'Minitab', 'QGIS', 'ArcGIS', 'Remote Sensing'],
    professionalSkills: ['Project Management', 'Structural Analysis', 'Site Investigation', 'Construction Management', 'Sustainable Engineering', 'Regulatory Compliance'],
    languages: ['English', 'Hindi', 'Assamese'],
  },
  projects: [
    { title: 'Morphometric Analysis of Aie River Basin', level: 'M.Tech Final Year Project', date: '2024 – 2025', description: "An in-depth analysis of the Aie River Basin's geomorphometric characteristics to understand its hydrological behavior and resource potential.", images: ['https://images.unsplash.com/photo-1566155620421-4d339b7495d4?q=80&w=400&h=300&fit=crop', 'https://images.unsplash.com/photo-1588615433796-037348926610?q=80&w=400&h=300&fit=crop', 'https://images.unsplash.com/photo-1543097023-4774883a4c14?q=80&w=400&h=300&fit=crop'] },
    { title: 'Reliability of Reinforced Concrete Bridges in North-East India', level: 'B.Tech Final Year Project', date: '2022 – 2023', description: "A comprehensive study on the structural health and reliability of existing reinforced concrete bridges, crucial for regional infrastructure planning.", images: ['https://images.unsplash.com/photo-1582211609782-b4a7d3c05972?q=80&w=400&h=300&fit=crop', 'https://images.unsplash.com/photo-1618114612399-253c2a6a163a?q=80&w=400&h=300&fit=crop'] },
    { title: 'Compressive Strength of M40 Concrete with Varied Aggregates', level: 'Diploma Final Year Project', date: '2019 – 2020', description: "An experimental investigation into how different aggregate grades affect the compressive strength of M40 concrete, providing insights for material optimization.", images: ['https://images.unsplash.com/photo-1519409393393-ea36b1192e4a?q=80&w=400&h=300&fit=crop', 'https://images.unsplash.com/photo-1579529363564-90924e2c0798?q=80&w=400&h=300&fit=crop', 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?q=80&w=400&h=300&fit=crop'] },
  ],
  accomplishments: {
    certifications: ['Diploma in Computer Application', 'CAD using Auto CAD'],
    awards: ['Anundoram Borooah Award, Government of Assam - 2015'],
    workshops: ['Groundwater Development & Management', 'Hydraulic Measurement Techniques (NIT Rourkella)', 'QSWAT Modeling (National Institute of Hydrology)', '3D Printing (TRTC, Guwahati)'],
    webinars: ['High Strength High Performance Concrete', 'Ground Improvement Techniques in Geotechnical'],
    interests: ['Swimming', 'Travelling', 'Reading'],
  },
  testimonials: [
    { quote: "Safikur's dedication and analytical skills were evident in his final year project. He has a bright future in hydraulic engineering.", name: "Dr. A. B. Sharma", title: "Professor, Central Institute of Technology" },
    { quote: "During his internship, Safikur was a quick learner and a proactive team member. He showed great potential in construction management.", name: "Er. C. D. Das", title: "Executive Engineer, P.W.D." },
  ]
};